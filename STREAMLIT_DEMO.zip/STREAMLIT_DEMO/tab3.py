import streamlit as st
import pandas as pd
import matplotlib.pyplot as mpl
import plotly.express as px
# import pyodbc
import pandas as pd



st.set_page_config(layout="wide")

st.title("Employees Data")

# Sample Data
alldata=pd.read_excel('emp.xlsx')

row1=st.columns(4)

with row1[0]:
    search=st.text_input('Search Department:', width=500)

with row1[1]:
    sel=st.selectbox('Choose:',['All']+list(alldata['City'].unique()))

with row1[2]:
    maxage = st.slider("Select Max Age:", 0, 100,100)
    
with row1[3]:
    gen = st.radio('Gender',['Male','Female'])

data=alldata.copy()
if(search):
    data=data[data['Department']==search]
    
if(sel!='All'):
    data=data[data['City']==sel]
    
if(maxage):
    data=data[data['Age']<=maxage]
    
if(gen):
    data=data[data['Gender']==gen]
  
#---------------------------------------------------------------  
    
row2=st.columns(3)

with row2[0]:
    st.metric('Total Employees',data['Salary'].sum(),border=True, format='compact')
    
with row2[1]:
    st.metric('Total Employees',data['EEID'].count(),border=True, format='compact')
    
with row2[2]:
    x=data[data['DOJ'].dt.year==2025]
    y=data[data['DOJ'].dt.year==2024]
    st.metric('Joined Last Yr',len(x),border=True, format='compact')
    
    
row3=st.columns(2)

with row3[0]:
    st.write(data)

