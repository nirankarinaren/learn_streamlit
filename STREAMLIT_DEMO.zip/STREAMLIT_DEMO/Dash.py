import streamlit as st
import pandas as pd
import matplotlib.pyplot as mpl
import plotly.express as px

st.set_page_config(layout="wide")

st.title("📊 Dashboard Grid Layout")

# Sample Data
alldata=pd.read_excel('emp.xlsx')


year_list = ['All'] + sorted(alldata['DOJ'].dt.year.unique())
data = alldata

    

selected_year = st.sidebar.selectbox("Select Year", year_list)
if selected_year == 'All':
    data = alldata
else:
    data = alldata[alldata['DOJ'].dt.year == selected_year]
# 🔹 ROW 1
row1 = st.columns(4)

with row1[0]:
    st.metric("Total Employees", data['EEID'].count(), "+26.8%")

with row1[1]:
    st.metric("Avg Salary", round(data['Salary'].mean(),2), "+26.8%")

with row1[2]:
    st.metric("Total Males", (data['Gender']=='Male').sum(), "+26.8%")
    
with row1[3]:
    st.metric("Total Females", (data['Gender']=='Female').sum(), "+26.8%")
    
    
# 🔹 ROW 2
row2 = st.columns(2)

with row2[0]:
    st.subheader("Dept Wise Salaries")
    ans1=data.groupby('Department')['Salary'].sum()
    st.bar_chart(ans1,horizontal=True)

with row2[1]:
    st.subheader("Month Wise Joining")
    ans2=data.groupby(data['DOJ'].dt.month_name())['EEID'].count()
    st.line_chart(ans2)

# 🔹 ROW 3
row3 = st.columns(3)

with row3[0]:
    st.subheader("Total Employees Gender Wise")
    ans3 = data.groupby('Gender')['EEID'].count().reset_index()
    fig = px.pie(ans3, names='Gender', values='EEID', hole=0.4)
    st.plotly_chart(fig)

with row3[1]:
    st.subheader("Total Employees in Each Business Unit")
    ans4 = data.groupby('Business Unit')['EEID'].count()
    st.bar_chart(ans4, color='green')

with row3[2]:
    st.subheader("Quarter Wise Salary Expenditure")
    ans5=data.groupby(data['DOJ'].dt.quarter)['Salary'].sum()
    st.line_chart(ans5)