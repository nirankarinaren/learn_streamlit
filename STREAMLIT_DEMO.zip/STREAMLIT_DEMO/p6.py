import streamlit as st
import pandas as p

st.set_page_config(layout="wide")
st.title("Sales Dashboard")

df = p.read_excel('emp.xlsx')

# Create 2 columns (Left = buttons, Right = output)
col1, col2 = st.columns([1, 4])  # left small, right big

# Buttons in Column 1
with col1:
    st.subheader("Controls")
    btn1 = st.button("Display Table", width=200)
    btn2 = st.button("Display Line Chart", width=200)
    btn3 = st.button("Display Bar Chart", width=200)

# Output in Column 2
with col2:
    st.subheader("Output")

    if btn1:
        st.write(df)
       

    elif btn2:
        st.line_chart(df, x='Full Name', y='Salary')

    elif btn3:
        st.bar_chart(df, x='Full Name', y='Salary')