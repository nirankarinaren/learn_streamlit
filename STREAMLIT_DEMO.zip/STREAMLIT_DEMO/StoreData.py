import streamlit as st
import pandas as pd
import matplotlib.pyplot as mpl
import plotly.express as px
import pyodbc
import pandas as pd
print(pyodbc.drivers())
conn = pyodbc.connect(
    "DRIVER=ODBC Driver 17 for SQL Server;"
    "SERVER=SERVER\SQLEXPRESS;"
    "DATABASE=mahek_db;"
    "Trusted_Connection=yes;"
)
cur=conn.cursor()
st.set_page_config(layout="wide")

st.image('https://www.pngitem.com/pimgs/m/208-2088584_employee-png-transparent-png.png', width=200)

st.title("Add Employees Data")

a1=st.number_input('Emp ID: ',value=101)
a2=st.text_input('Firstname: ')
a3=st.text_input('Lastname: ')
a4=st.date_input('Birth Date: ',min_value='1990-01-01')
a5=st.text_input('Phone Number: ')
a6=st.radio('Gender: ',['M','F'])
a7=st.text_input('City: ')
a8=st.number_input('Salary: ', value=10000)

btn=st.button('Submit')

if(btn):
    query="insert into employee_info values ('%i','%s','%s','%s','%s','%s','%s','%i')"%(a1,a2,a3,a4,a5,a6,a7,a8)

    cur.execute(query)

    conn.commit()
    
    st.subheader('Employee Added Successfully...')



  

