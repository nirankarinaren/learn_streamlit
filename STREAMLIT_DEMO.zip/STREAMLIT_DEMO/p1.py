import streamlit as st
import pandas as p

st.set_page_config(layout="wide")
st.title("Sales Dashboard")

df = p.read_excel('emp.xlsx')

col1, col2 = st.columns([1, 4])

# Initialize session state
if "view" not in st.session_state:
    st.session_state.view = None

# Buttons (left side)
with col1:
    st.subheader("Controls")

    if st.button("Display Table" , width=200):
        st.session_state.view = "table"

    if st.button("Display Line Chart", width=200):
        st.session_state.view = "line"

    if st.button("Display Bar Chart", width=200):
        st.session_state.view = "bar"

# Output (right side)
with col2:
    st.subheader("Output")
    search = st.text_input("Search Department")
    if st.session_state.view == "table":
        if search:
            filtered_df = df[df['Department'].str.contains(search, case=False, na=False)]
            st.dataframe(filtered_df, use_container_width=True)
        else:
            st.dataframe(df, use_container_width=True)

    elif st.session_state.view == "line":
        if search:
            filtered_df = df[df['Department'].str.contains(search, case=False, na=False)]
            st.line_chart(filtered_df, x='Full Name', y='Salary')
        else:
            st.line_chart(df, x='Full Name', y='Salary')

    elif st.session_state.view == "bar":
        if search:
            filtered_df = df[df['Department'].str.contains(search, case=False, na=False)]
            st.bar_chart(filtered_df, x='Full Name', y='Salary',color='yellow')
        else:
            st.bar_chart(df, x='Full Name', y='Salary',color='yellow')