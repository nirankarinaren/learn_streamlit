import streamlit as st
import pandas as p
st.set_page_config(layout="wide")
st.title("Sales Dashboard")
df = p.read_excel('emp.xlsx')

col1, col2, col3 = st.columns(3)
with col1:
    if(st.button('Display Table')):
        st.write(df, col3)
  
with col2:  
    if(st.button('Display Line Chart')):
        st.line_chart(df,x='Full Name',y='Salary',color='red')
 
with col3:   
    if(st.button('Display Bar Chart')):
        st.bar_chart(df,x='Full Name',y='Salary',color='red',y_label='Salary Amount', x_label='Employee Name')


