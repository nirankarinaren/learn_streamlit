import streamlit as st

# Page config must be the first Streamlit command
st.set_page_config(
    page_title="Multi-Page App",
    page_icon="🚀",
    layout="wide"
)

st.title("Welcome to the Multi-Page App")
st.sidebar.success("Select a page above.")

st.markdown("""
### Main Home Page
This is the entry point of your application. 
- Navigate using the sidebar to the left.
- Each page is a separate file in the `pages/` directory.
- Data can be shared across pages using `st.session_state`.
""")

# Example of shared state
if "user_name" not in st.session_state:
    st.session_state.user_name = "Guest"

user_input = st.text_input("Enter your name to personalize the app:", st.session_state.user_name)
st.session_state.user_name = user_input