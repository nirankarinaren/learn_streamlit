import streamlit as st

st.set_page_config(page_title="About", page_icon="ℹ️")

st.title("About This Project")

st.info("This app demonstrates how Streamlit handles native multi-page navigation.")

st.markdown("""
- **Framework:** Streamlit
- **Language:** Python
- **Navigation Style:** Native File-Based
""")