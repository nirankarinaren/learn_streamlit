import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="Dashboard", page_icon="📊")

st.title(f"Dashboard for {st.session_state.user_name}")
st.write("Here is some mock data visualization.")

# Create some random data
chart_data = pd.DataFrame(
    np.random.randn(20, 3),
    columns=['Category A', 'Category B', 'Category C']
)

st.line_chart(chart_data)

st.subheader("Data Summary")
st.write(chart_data.describe())