import streamlit as st
import pandas as p

st.title("Sales Dashboard")

uploaded_files = st.file_uploader(
    "Upload data", accept_multiple_files=True, type="xlsx"
)
for uploaded_file in uploaded_files:
    df = p.read_excel(uploaded_file)
    st.write(df)
   
