import streamlit as st
import pandas as p
st.set_page_config(layout="wide")
st.title("Sales Dashboard")
df = p.read_excel('emp.xlsx')
col1, col2, col3 = st.columns(3)

btn1 = col1.button('Display Table')
btn2 = col2.button('Display Line Chart')
btn3 = col3.button('Display Bar Chart')

if btn1:
    # st.dataframe(df, use_container_width=True)
    st.write(df)

elif btn2:
    st.line_chart(df, x='Full Name', y='Salary')

elif btn3:
    st.bar_chart(df, x='Full Name', y='Salary')
    
    
