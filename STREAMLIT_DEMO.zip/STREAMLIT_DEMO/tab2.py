import streamlit as st
import pandas as pd
import matplotlib.pyplot as mpl
import plotly.express as px
import pyodbc
import pandas as pd
print(pyodbc.drivers())
conn = pyodbc.connect(
    "DRIVER=ODBC Driver 17 for SQL Server;"
    "SERVER=SERVER\SQLEXPRESS;"
    "DATABASE=mahek_db;"
    "Trusted_Connection=yes;"
)

st.set_page_config(layout="wide")

st.title("Employees Data")

# Sample Data
alldata=pd.read_sql_query('select * from employee_info',conn)

col1,col2,col3=st.columns(3)

with col1:
    search=st.text_input('Search City:', width=500)

with col2:
    sel=st.selectbox('Choose:',['All']+list(alldata['City'].unique()))

with col3:
    maxage = st.slider("Select Max Age:", 0, 100,100)

data=alldata.copy()
if(search):
    data=data[data['City']==search]
    
if(sel!='All'):
    data=data[data['City']==sel]
    
if(maxage):
    data=data[data['Age']<=maxage]
    
st.write(data)

