import streamlit as st
import pandas as pd
import matplotlib.pyplot as mpl
import plotly.express as px


st.set_page_config(layout="wide")

st.title("Employees Data")

# Sample Data
alldata=pd.read_excel('emp.xlsx')

col1,col2,col3=st.columns(3)

with col1:
    search=st.text_input('Search Department:', width=500)

with col2:
    sel=st.selectbox('Choose:',['All']+list(alldata['Business Unit'].unique()))

with col3:
    maxage = st.slider("Select Max Age:", 0, 100,100)

data=alldata.copy()
if(search):
    data=data[data['Department']==search]
    
if(sel!='All'):
    data=data[data['Business Unit']==sel]
    
if(maxage):
    data=data[data['Age']<=maxage]
    
st.write(data)

